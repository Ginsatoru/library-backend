﻿namespace LibrarySystemBBU.Models
{
    public enum RoleEnum
    {
        Admin,
        Account,
        CreditOfficer,
        Manager,
        User
    }
}