﻿using System.Globalization;
using LibrarySystemBBU.Data;
using LibrarySystemBBU.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LibrarySystemBBU.Controllers
{
    public class DashboardController : Controller
    {
        private readonly DataContext _context;

        public DashboardController(DataContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var model = new DashboardViewModel();

            model.TotalBooks = await _context.Books.CountAsync();
            model.TotalLoans = await _context.BookLoans.CountAsync();

            // Pending returns = loans NOT returned and DueDate >= now
            model.PendingReturns = await _context.BookLoans
                .CountAsync(l => !l.IsReturned && l.DueDate >= DateTime.Now);

            // Overdue loans = loans NOT returned and DueDate < now
            model.OverdueLoans = await _context.BookLoans
                .CountAsync(l => !l.IsReturned && l.DueDate < DateTime.Now);

            // Returned books = loans that are returned
            model.ReturnedBooks = await _context.BookLoans
                .CountAsync(l => l.IsReturned);

            model.TotalMembers = await _context.Members.CountAsync();
         

            // For Monthly stats, group by LoanDate month/year
            var loans = await _context.BookLoans
                .Where(l => l.LoanDate != null)
                .ToListAsync();

            var monthlyGroups = loans
                .GroupBy(l => new { l.LoanDate.Year, l.LoanDate.Month })
                .OrderBy(g => g.Key.Year)
                .ThenBy(g => g.Key.Month)
                .ToList();

            model.MonthlyLabels = monthlyGroups
                .Select(g => CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(g.Key.Month) + " " + g.Key.Year)
                .ToList();

            model.MonthlyLoanStats = monthlyGroups.Select(g => g.Count()).ToList();

            // If you want member stats monthly, replace with your own logic, here dummy zeros
            model.MonthlyMemberStats = monthlyGroups.Select(_ => 0).ToList();

            // Last 7 days daily loan stats
            var last7Days = DateTime.Today.AddDays(-6);

            var dailyGroups = loans
                .Where(l => l.LoanDate.Date >= last7Days)
                .GroupBy(l => l.LoanDate.Date)
                .OrderBy(g => g.Key)
                .ToList();

            model.DailyLabels = dailyGroups
                .Select(g => g.Key.ToString("MMM dd"))
                .ToList();

            model.DailyLoanStats = dailyGroups
                .Select(g => g.Count())
                .ToList();

            return View(model);
        }
    }
}
